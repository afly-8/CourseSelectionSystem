// app.js
App({
  data: {
    selected: 0,
    list: [
      {
        "pagePath": "pages/index/index",
        "text": "首页",
        "iconPath": "/images/s1d.png",
        "selectedIconPath": "/images/s1.png"
      },
      {
        "pagePath": "pages/logs/logs",
        "text": "日志",
        "iconPath": "/images/s2.png",
        "selectedIconPath": "/images/s2d.png"
      }
    ]
  },
  onLaunch() {

  },
  globalData: {
    userInfo: null,
    PageActive: true,
    domain: "https://api.cooxl.cn"
  },
  preventActive (fn) {
    const self = this
    if (this.globalData.PageActive) {
      this.globalData.PageActive = false
      if (fn) fn()
      self.globalData.PageActive = true
    } else {
      console.log('重复点击或触发')
    }
  }
})
