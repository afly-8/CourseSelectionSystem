const app=getApp()
Page({
  data: {
    page_show:false,
    navHeight: '',
    menuButtonInfo: {},
    searchMarginTop: 0, // 搜索框上边距
    searchWidth: 0, // 搜索框宽度
    searchHeight: 0 ,// 搜索框高度
    //初始化数据
    width: 0,
    ismove:false,
    time:0,
    notice: "请大家及时参加选课！！！",
    subjects: [
    ],
    search: null,
    showModal:false,
    teachInfo:{},
    status:false, //登陆模态框
  },
  selectSub: function(e) {
    this.setData({
      teachInfo :{
        name:e.currentTarget.dataset.name,
        role:e.currentTarget.dataset.tname,
        time:e.currentTarget.dataset.time,
        place:e.currentTarget.dataset.place,
        cid:e.currentTarget.dataset.cid
      }
    });
    this.toShowModal();
  },

  onCancel: function() {
    this.hideModal();
  },

  onChoose: function() {
    var sid = wx.getStorageSync('sid');
    var cid = this.data.teachInfo.cid;
    const that = this;
    if (sid != null && sid != '') {
      // 选课操作
      wx.showLoading({
        title: '选课中',
      })
      wx.request({
        url: app.globalData.domain+"/student/scourse",
        method: 'post',
        data: {
          sid: sid,
          cid: cid
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded',
          "access-token": wx.getStorageSync('access-token')
        },
        success: function (res) {
          wx.hideLoading()
          if(res.data.code == 10000) {
            // 选课成功
            wx.showToast({
              title: res.data.msg,
              icon: "success",
              duration: 1000//持续的时间
            })
            that.hideModal();
            const pages = getCurrentPages()
            const perpage = pages[pages.length - 1]
            perpage.onLoad()
          } else{
            wx.showToast({
              icon: 'error',
              title: res.data.msg,
            })
            if (res.data.msg=="登录过期！") {
              wx.clearStorageSync()
              that.setData({
                status:true
              })
              that.hideModal();
              const pages = getCurrentPages()
              const perpage = pages[pages.length - 1]
              perpage.onLoad()
            }
          }
        },
        fail: function (err) {
          wx.showToast({
            icon:'error',
            title: '选课失败，服务异常！',
            duration: 500//持续的时间
          })
        }
      })
    } else {
      wx.showToast({
        title: '未登陆，请登陆！',
        icon: 'error',
        duration: 500//持续的时间
      })
      this.hideModal();
      // 显示登陆模态框
      this.setData({
        status:true
      })
    }
  },
  handlecancel(){
    this.setData({
      status:false
    })
  },
  handleConfirm(){
    this.setData({
      status:false,
    })
  },
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    getCourse(that);
    wx.request({
      url: app.globalData.domain+'/wx/news/getAll', //真实的接口地址
      data: {},
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        wx.hideLoading()
        that.setData({  
          ArticleList: res.data.data
        }) 
      },
      fail: function (err) {
        console.log(err)
      }
    })

    var systeminfo=wx.getSystemInfoSync()
    //console.log(systeminfo.windowHeight)
    this.setData({
      movehight:systeminfo.windowHeight,
      movehight2:systeminfo.windowHeight-100
    })
 
    this.setData({
      menuButtonInfo: wx.getMenuButtonBoundingClientRect()
    })
    const { top, width, height, right } = this.data.menuButtonInfo
    wx.getSystemInfo({
      success: (res) => {
        const { statusBarHeight } = res
        const margin = top - statusBarHeight
        this.setData({
          navHeight: (height + statusBarHeight + (margin * 2)),
          searchMarginTop: statusBarHeight + margin, // 状态栏 + 胶囊按钮边距
          searchHeight: height,  // 与胶囊按钮同高
          searchWidth: right - width -20// 胶囊按钮右边坐标 - 胶囊按钮宽度 = 按钮左边可使用宽度
        })
      }
    })

    function getCourse(that){
      var that = that;
      wx.request({
        url: app.globalData.domain+'/course/wx/getCourse', //真实的接口地址
        data: {},
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          that.setData({  
            subjects:res.data.data
          })  
        },
        fail: function (err) {
          console.log(err)
        }
      })
    }
  },
  /**
   * 搜索按钮
   */
  searchs: function (e) {
    var that = this;
      wx.request({
        url: app.globalData.domain+'/course/wx/getCourse', //真实的接口地址
        data: {
          queryStr:e.detail.value
        },
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          that.setData({  
            subjects:res.data.data
          })  
        },
        fail: function (err) {
          console.log(err)
        }
      })
  },

  toShowModal: function(e) {
    this.setData({
      showModal: true
    })
  },

  hideModal: function(){
    this.setData({
      showModal: false
    });
  }
})