// index.js
// 获取应用实例
// import Toast from '@vant/weapp/toast/toast';
const app = getApp()

Page({
  data: {
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    imgUrls: [
       'https://api.cooxl.cn/img/wx/b1.png',
       'https://api.cooxl.cn/img/wx/b2.png',
       'https://api.cooxl.cn/img/wx/b3.png',
     ],
     s1: '课程介绍',
     s2: '教师查询',
     s3: '校园服务',
     s4: '更多服务',
     imgShow : false,
     ArticleList: [
    ]
  },
  /**
   * 进入文章详情界面
   */
  gotoArticleDetail: function (event) {
    // 当前要跳转到另一个界面，但是会保留现有界面
    wx.navigateTo({
      url: '../content/content?id='+event.currentTarget.dataset.id+'&text='+event.currentTarget.dataset.title
    })
  },

  gotoArticleDetail1: function (event) {
    wx.navigateTo({
      url: '../sy/i1/i1'
    })
  },
  gotoArticleDetail2: function (event) {
    wx.navigateTo({
      url: '../sy/i2/i2'
    })
  },
  gotoArticleDetail3: function (event) {
    wx.navigateTo({
      url: '../sy/i3/i3'
    })
  },
  gotoArticleDetail4: function (event) {
    wx.navigateTo({
      url: '../sy/i4/i4'
    })
  },

  onLoad: function () {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    wx.request({
      url: app.globalData.domain+'/wx/news/getAll', //真实的接口地址
      data: {},
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        wx.hideLoading();
        that.setData({  
          ArticleList: res.data.data
          // 设置数据 json： s1: res.data;
        })  
      },
      fail: function (err) {
        console.log(err)
      }
    })
  },
})
