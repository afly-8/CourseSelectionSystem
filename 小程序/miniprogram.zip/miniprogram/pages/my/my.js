// pages/my/my.js
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    status:false,
    loginName:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var lname = wx.getStorageSync('loginName');
    if (lname != '' && lname != null) {
      this.setData({
        loginName: lname,
      })
    } else {
      this.setData({
        loginName: "登陆",
      })
    }
  },

  clickNum:function (e) {
    this.handleTap();
  },

  handleTap(){
    this.setData({
      status:true
    })
  },
  handlecancel(){
    this.setData({
      status:false
    })
  },
  handleConfirm(){
    var lname = wx.getStorageSync('loginName');
    this.setData({
      status:false,
      loginName: lname,
    })
  }
})