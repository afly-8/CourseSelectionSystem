// component/dialog/index.js
const app = getApp()
Component({
    /**
     * 组件的属性列表
     */
    properties: {
      title:{
        type:String,
        value:"学生登陆"
      },
      content:String,
      status:{
        type:Boolean,
        value:false,
  
      }
    },
  
    /**
     * 组件的初始数据
     */
    data: {
      sid:null,
      passwd:null,
    },
  
    /**
     * 组件的方法列表
     */
    methods: {
      //获取用户输入的用户名
      userNameInput:function(e)
      {
        this.setData({
          sid: e.detail.value
        })
      },
      passWdInput:function(e)
      {
        this.setData({
          passwd: e.detail.value
        })
      },
      handleCancel(){
        this.triggerEvent("cancel")
      },
      handleConfirm(e){
        this.triggerEvent("confirm")
        var that = this;
        wx.showLoading({
          title: '加载中',
        })
        wx.request({
          url: app.globalData.domain+'/student/login', //真实的接口地址
          method:"post",
          data: {
            sid:this.data.sid,
            passwd:this.data.passwd
          },
          header: {
            'content-type': 'application/json'
          },
          success: function (res) {
            wx.hideLoading()
            if(res.data.code==10000) {
              that.setData({
                // 设置数据 json： s1: res.data;
              })
              wx.setStorageSync("access-token", res.data.msg)
              wx.setStorageSync("loginName", res.data.data.name)
              wx.setStorageSync("scid", res.data.data.scid)
              wx.setStorageSync("sid", res.data.data.sid)
              wx.showToast({
                title: res.data.data.name+'登陆成功！',
                icon: 'success',
                duration: 2000 //持续的时间
              })
              const pages = getCurrentPages()
              const perpage = pages[pages.length - 1]
              perpage.onLoad()  
            } else {
              wx.showToast({
                title: '学号或密码！',
                icon: 'error',
                duration: 2000//持续的时间
              })
            }

          },
          fail: function (err) {
            console.log(err)
            wx.showToast({
              title: '请求失败！',
              icon: 'none',
              duration: 2000//持续的时间
            })
          }
        })
      }
    }
  })